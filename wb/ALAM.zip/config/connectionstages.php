<?
$dbservererp='localhost';
$dbport  ='3306';
$dbnameerp  ='bakrie';
$unameerp	='root';
$passwderp	='p';

try{
$owlPDOERP = new PDO('mysql:host='.$dbservererp.';dbname='.$dbnameerp, $unameerp, $passwderp, array(PDO::ATTR_PERSISTENT => false));
$owlPDOERP->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
}
catch (PDOException $e) {
       print " Gagal, could not connect\n";	
       print "Error!: " . $e->getMessage() . "<br/>";
   die();
}
?>
