TIMEOUT 3
cd C:\Users\wanda\Documents\project\nodejs\serialport\indikator
node index.js