const { SerialPort } = require('serialport')
const express = require('express')
require('dotenv').config();
const app = express()
const fs = require('fs')
const portt = 300;
let serv =  app.listen(portt)
const fetch = require('node-fetch');
const chalk = require('chalk');
const readlineSync = require('readline-sync');
const waitPort = require('wait-port');

(async () => {
  const params = {
    host: process.env.SERVER_TIMBANGAN || 'localhost',
    port: 80,
  };
  const mysql = {
    host: process.env.SERVER_DATABASE,
    port: 3306,
  };
  console.log(chalk.bgCyan('Menunggu website timbangan berjalan'));
  await waitPort(params)
  .then(({ open, ipVersion }) => {
    if (open) console.log(chalk.green('website timbangan sudah berjalan'));
    else console.log(chalk.red('website timbangan gagal berjalan!!'));
  })
  .catch((err) => {
    console.err(`An unknown error occured while waiting for the port: ${err}`);
  });
  console.log(chalk.bgCyan('Menunggu server database berjalan'));
  await waitPort(mysql)
  .then(({ open, ipVersion }) => {
    if (open) console.log(chalk.green('Server database sudah berjalan'));
    else console.log(chalk.red('Server database gagal berjalan!!'));
  })
  .catch((err) => {
    console.err(`An unknown error occured while waiting for the port: ${err}`);
  });
  const timbangan = await fetch(`http://${process.env.SERVER_TIMBANGAN}/wb/api.php?method=getport`);
  const dataTimbangan = await timbangan.json();
  const {path,databit,baudRate,parity} = {
    path : process.env.PORT_TIMBANGAN || dataTimbangan.data.port,
    databit: process.env.DATABIT_TIMBANGAN || dataTimbangan.data.databit,
    baudRate: process.env.BAUDRATE_TIMBANGAN || dataTimbangan.data.baudrate,
    parity: process.env.PARITY_TIMBANGAN || dataTimbangan.data.parity
  };
  await console.log(chalk.bgMagenta(`Menghubungkan ke port ${path} dengan baudrate: ${baudRate}`));
  const port = new SerialPort({ 
    path: path, 
    baudRate: parseInt(baudRate),
    parity: parity,
    databit: databit
  }).setEncoding('utf8')
  // console.log(datas.port);
  port.on('readable', () => {
    let data = port.read().toString('utf8');
    if(data != null){
      fs.appendFile('indikator.txt',data, 'utf8',() => {});
      console.log(chalk.bgGreen('Aplikasi sudah berjalan, mohon jangan diclose'));
      // fs.writeFileSync('qr.txt',data, 'utf8');
      // fs.writeFile('qr.txt',data,'utf8',(err) => {
      //   if(err) console.error('errror');
      // });
    }
  
  });
  app.get('/', (req, res) => {
      fs.readFile('indikator.txt', 'utf8', (err, data) => {
        let respon;
        if(!data || err){
          res.statusCode = 404;
          respon  = {
            status: false,
            msg: 'Indikator tidak terbaca'
          }
        }else{
          res.statusCode = 200;
          let datas = data.split("\r");
          //edit bagian sini untuk pembacaan indikator
          let beratIndikator = datas.length > 0 ? datas[datas.length - 2].replaceAll("\n \u0002",'').replaceAll('kg','').replace('    ','').replace('  ','').replace("\u0002",'') : '0';
          respon  = {
            status: true,
            msg: beratIndikator
          }
        }
        res.json(respon);
        fs.truncate('indikator.txt', 0, (err) => {})
      });
      // await serv.close();
      // await app.listen(portt)
    });
  
  
  // Switches the port into "flowing mode"
  // port.on('data', function (data) {
  //   console.log('Data:', data)
  // })
  
  // Open errors will be emitted as an error event
  port.on('error', function(err) {
    console.log(chalk.bgRed('Error'), chalk.redBright(err.message));
    console.log(chalk.bgYellow('Silahkan setting port di parameter aplikasi dan  restart aplikasi owl.bat atau restart komputer setelah melakukan setting port di aplikasi weighbridge'))
  })
})();